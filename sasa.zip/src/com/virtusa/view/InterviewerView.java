package com.virtusa.view;
import java.util.List;
import java.util.Scanner;
import com.virtusa.controller.InterviewerController;
import com.virtusa.model.InterviewerModel;
import com.virtusa.utilities.UserTypes;

public class InterviewerView {
	Scanner scanner = new Scanner(System.in);
	InterviewerModel interviewerModel = new InterviewerModel();
	public void interviewerView() {
		System.out.println("=======Interviewer View======");
		System.out.println("please enter option");
		System.out.println(" 1.view all apllicant name ");
		System.out.println(" 2.update the result");
		int option = scanner.nextInt();
		if (option == 1) {
viewApplicantView();
} else if (option == 2) {
			UpdateResult();
		} else {
			System.out.println("please enter valid option");
		}
	}
public void UpdateResult() {
	Scanner scanner = new Scanner(System.in);
    	System.out.print("Enter applicant name: ");
    	 String applicantName=scanner.nextLine();
		System.out.println("Enter result : ");
		String applicantResult = scanner.nextLine();
		interviewerModel.setApplicant_name(applicantName);
		interviewerModel.setResult(applicantResult);
        InterviewerController interviewerController = new InterviewerController();
		interviewerController.handleRegisterMarks(interviewerModel);
}
         public void showMarksUpdated(InterviewerModel model) {
 		System.out.println("data successfully stored : ");
}
        public void marksUpdationFail(InterviewerModel model) {
		System.out.println("data not stored : ");
}
	public void viewApplicantView() {
		try (Scanner scanner = new Scanner(System.in);) {
			System.out.println("1. View applicant Name and Result");
			System.out.println("2 update the result ");
				System.out.print("Enter choice:");
			int option = scanner.nextInt();
			InterviewerController interviewerController = new InterviewerController();
			if (option == 1)
			interviewerController.handleRetriveApplicant(UserTypes.INTERVIEWER);
			else if(option==2)
			{
				UpdateResult();
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
public static void showApplicant(List<InterviewerModel> models) {
		for (InterviewerModel model : models) {
			System.out.print(model.getApplicant_name()+"  ------   ");
			System.out.println(model.getResult());
		}
	}
}

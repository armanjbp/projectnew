package com.virtusa.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.virtusa.dao.InterviewerDAO;
import com.virtusa.dao.InterviewerDAOImpl;

import com.virtusa.entities.Interviewer;

class TestJDBCEmployeesDAOImpl 
{

	@Test
	public void testGetAllinterviewer_positive() throws ClassNotFoundException {
		InterviewerDAO interviewerDAO=
				new InterviewerDAOImpl();
		
		try {
			List<Interviewer> applicantList=
					interviewerDAO.getAllApplicant();
			assertEquals(true,applicantList.size()<0);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		}
		
		
	}

}

package com.virtusa.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.entities.Interviewer;

public  interface InterviewerDAO 
{
public boolean storeMarks(Interviewer interviewer) throws SQLException;
public List<Interviewer> getAllApplicant() throws SQLException;
}

package com.virtusa.view;

public class ManagerView {
	public void managerView() {
		System.out.println("=======Manager View======");
	}
}

package com.virtusa.entities;

public class Interviewer extends User{
	
public Interviewer() {
		
	}
	private int marks;

	private String interviewerId;
	
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
	public String getInterviewerId() {
		return interviewerId;
	}
	public void setInterviewerId(String interviewerId) {
		this.interviewerId = interviewerId;
	}
	@Override
	public String toString() {
		return "Interviewer [marks=" + marks 
				+ ", interviewerId=" + interviewerId + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((interviewerId == null) ? 0 : interviewerId.hashCode());
		result = prime * result + marks;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Interviewer other = (Interviewer) obj;
		if (interviewerId == null) {
			if (other.interviewerId != null)
				return false;
		} else if (!interviewerId.equals(other.interviewerId))
			return false;
		if (marks != other.marks)
			return false;
		return true;
	}
	
	
	
	
}

package com.virtusa.model;

public class InterviewerModel
{
	private int marks;
	public InterviewerModel() {}
  
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "InterviewerModel [marks=" + marks + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + marks;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InterviewerModel other = (InterviewerModel) obj;
		if (marks != other.marks)
			return false;
		return true;
	}
	
	
	
	
	
	
	

}

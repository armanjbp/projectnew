package com.virtusa.service;

import com.virtusa.model.AdminModel;

public interface AdminService {
	public boolean storeJobService(AdminModel adminmodel);
}

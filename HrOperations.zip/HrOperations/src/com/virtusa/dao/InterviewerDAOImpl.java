package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

import com.virtusa.dbconnection.ConnectionManager;
import com.virtusa.entities.Interviewer;
import com.virtusa.repository.InterviewerRepository;

public class InterviewerDAOImpl implements InterviewerDAO {
	public boolean storeMarks(Interviewer interviewer) throws SQLException {
		Connection connection = ConnectionManager.openConnection();
		PreparedStatement preparedStatement = connection
				.prepareStatement("insert into interviewer values(?,?)");
		preparedStatement.setInt(1, interviewer.getMarks());
		preparedStatement.setString(2, interviewer.getInterviewerId());
		int rows = preparedStatement.executeUpdate();
		if (rows > 0) {
			return true;
		} else
			return false;

	}

}

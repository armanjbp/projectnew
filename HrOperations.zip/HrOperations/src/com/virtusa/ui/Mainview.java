package com.virtusa.ui;


import com.virtusa.view.InterviewerView;

public class Mainview 
{
	public static void main(String args[])
	{
	InterviewerView interviewer=new InterviewerView();
	interviewer.interviewerView();
	}
}

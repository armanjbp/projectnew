package com.virtusa.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Testcon {
	private static DataSource dataSource = new DataSource();

	public static void main(String args[]) {
		try {
			Class.forName(dataSource.getDriver());
			Connection conn = DriverManager.getConnection(dataSource.getUrl(),
					dataSource.getUsername(), dataSource.getPassword());
			Statement stmt= conn.createStatement();
		ResultSet rs=	stmt.executeQuery("select * from interviewer");
		while(rs.next())
		{
			System.out.println(rs.getInt(2));
		}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
